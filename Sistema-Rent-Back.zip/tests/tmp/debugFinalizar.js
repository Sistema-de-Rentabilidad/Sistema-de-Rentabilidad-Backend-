process.env.NODE_ENV = 'qa';

const request = require('supertest');
const app = require('../../src/app');
const pool = require('../../src/config/db');

const { login } = require('../helpers/auth');
const {
    crearProyectoTemporal,
    eliminarProyectoTemporal
} = require('../helpers/proyecto.helper');

(async () => {
    try {
        const auth = await login('qa_lider@test.com', 'Qa123456*');

        const proyecto = await crearProyectoTemporal();

        const fechaAntes = new Date();

        const response = await request(app)
            .put(`/api/proyectos/${proyecto.id_proyecto}/finalizar`)
            .set('Cookie', auth.cookies);

        console.log('response.status:', response.status);
        console.log('response.body:', JSON.stringify(response.body, null, 2));

        const result = await pool.query(
            `SELECT fecha_fin_real FROM proyecto WHERE id_proyecto = $1`,
            [proyecto.id_proyecto]
        );

        console.log('db.rows:', JSON.stringify(result.rows, null, 2));

        if (result.rows.length > 0) {
            const fechaFinal = new Date(result.rows[0].fecha_fin_real);
            console.log('fechaAntes (ISO):', fechaAntes.toISOString());
            console.log('fechaFinal (ISO):', fechaFinal.toISOString());
            console.log('diffMs:', Math.abs(fechaFinal - fechaAntes));
        }

        await eliminarProyectoTemporal(proyecto.id_proyecto);
        await pool.end();
        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
})();
