const pool = require('../../src/config/db');

(async () => {
    try {
        const sql = `
      SELECT 
        tc.constraint_name,
        tc.table_name,
        kcu.column_name,
        ccu.table_name AS foreign_table_name,
        ccu.column_name AS foreign_column_name,
        rc.update_rule,
        rc.delete_rule
      FROM information_schema.table_constraints AS tc
      JOIN information_schema.key_column_usage AS kcu
        ON tc.constraint_name = kcu.constraint_name
      JOIN information_schema.referential_constraints AS rc
        ON tc.constraint_name = rc.constraint_name
      JOIN information_schema.constraint_column_usage AS ccu
        ON rc.unique_constraint_name = ccu.constraint_name
      WHERE tc.constraint_type = 'FOREIGN KEY'
        AND ccu.table_name = 'usuario'
        AND ccu.column_name = 'id_usuario';
    `;
        const res = await pool.query(sql);
        console.log(JSON.stringify(res.rows, null, 2));
    } catch (err) {
        console.error(err);
        process.exit(1);
    } finally {
        await pool.end();
    }
})();
